public class Word {

    private String english;
    private String czech;

    public Word(String english, String czech) {
        this.english = english;
        this.czech = czech;
    }

    public String getEnglish() {
        return english;
    }

    public String getCzech() {
        return czech;
    }
}

